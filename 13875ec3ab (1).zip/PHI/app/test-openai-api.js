// Test script to check if the OpenAI API key works
require('dotenv').config({ path: '.env.local' });

async function testOpenAIAPI() {
  try {
    console.log('Testing OpenAI API with key:', process.env.OPENAI_API_KEY.substring(0, 10) + '...');
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'Hello, are you working?' }],
        max_tokens: 50
      })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      console.log('API Response Status:', response.status);
      console.log('API Response:', data.choices[0].message.content);
      console.log('API Key is working correctly!');
    } else {
      console.error('API Error:', data);
      console.error('API Key is not working correctly.');
    }
  } catch (error) {
    console.error('Error testing OpenAI API:', error);
  }
}

testOpenAIAPI();
