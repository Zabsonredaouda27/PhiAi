// Simple script to test if the OpenAI API key is being loaded correctly
require('dotenv').config({ path: '.env.local' });

console.log('OPENAI_API_KEY from process.env:', process.env.OPENAI_API_KEY);
console.log('OPENAI_API_KEY first 10 chars:', process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.substring(0, 10) + '...' : 'undefined');
console.log('OPENAI_API_KEY format valid:', process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.startsWith('sk-'));
