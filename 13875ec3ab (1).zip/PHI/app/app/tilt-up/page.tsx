'use client';

import { useEffect, useState, useRef, useContext } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Map as MapIcon, 
  Plus, 
  Search, 
  MapPin, 
  Building, 
  Home, 
  Briefcase, 
  ShoppingBag, 
  Coffee, 
  Utensils, 
  Truck, 
  Share2, 
  Navigation, 
  X,
  Check,
  User,
  Clock
} from 'lucide-react';
import Link from 'next/link';

// Mock data for locations
const mockLocations = [
  {
    id: 1,
    name: "My Home",
    description: "My personal residence",
    address: "123 Main Street, Anytown",
    lat: 48.8584,
    lng: 2.2945,
    type: "personal",
    icon: "home",
    delivery: false,
    createdAt: "2023-05-15T10:30:00Z"
  },
  {
    id: 2,
    name: "Café Quantum",
    description: "Best coffee in the multiverse",
    address: "456 Quantum Avenue, Anytown",
    lat: 48.8634,
    lng: 2.3325,
    type: "business",
    icon: "coffee",
    delivery: true,
    createdAt: "2023-05-10T14:20:00Z"
  },
  {
    id: 3,
    name: "PHI Headquarters",
    description: "Main office of PHI Technologies",
    address: "789 Innovation Boulevard, Techville",
    lat: 48.8674,
    lng: 2.3095,
    type: "business",
    icon: "building",
    delivery: false,
    createdAt: "2023-04-28T09:15:00Z"
  },
  {
    id: 4,
    name: "Quantum Market",
    description: "Shopping center with interdimensional goods",
    address: "321 Reality Street, Multitown",
    lat: 48.8704,
    lng: 2.3155,
    type: "business",
    icon: "shopping",
    delivery: true,
    createdAt: "2023-05-01T16:45:00Z"
  }
];

export default function MapPhiPage() {
  const router = useRouter();
  const [selectedLocation, setSelectedLocation] = useState<any>(null);
  const [locations, setLocations] = useState(mockLocations);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newLocation, setNewLocation] = useState({
    name: '',
    description: '',
    address: '',
    type: 'personal',
    icon: 'home',
    delivery: false
  });

  // Filter locations based on search query
  const filteredLocations = locations.filter(location => 
    location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    location.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    location.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Add new location
  const handleAddLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocation.name.trim() || !newLocation.address.trim()) return;
    
    const location = {
      id: locations.length + 1,
      ...newLocation,
      lat: 48.8584 + (Math.random() - 0.5) * 0.1,
      lng: 2.2945 + (Math.random() - 0.5) * 0.1,
      createdAt: new Date().toISOString()
    };
    
    setLocations([location, ...locations]);
    setNewLocation({
      name: '',
      description: '',
      address: '',
      type: 'personal',
      icon: 'home',
      delivery: false
    });
    setShowAddForm(false);
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-blue-950 dark:to-blue-900">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-blue-900/80 backdrop-blur-md shadow-sm p-4">
        <div className="max-w-1200 mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center justify-center p-2 rounded-full bg-blue-100 dark:bg-blue-800 hover:bg-blue-200 dark:hover:bg-blue-700 transition-colors">
              <MapIcon className="text-blue-600 dark:text-blue-300" size={20} />
            </Link>
            <h1 className="ml-3 text-xl font-bold text-blue-700 dark:text-blue-200">Map φ</h1>
          </div>
          
          <button 
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus size={18} className="mr-2" />
            Add Location
          </button>
        </div>
      </header>

      <div className="max-w-1200 mx-auto p-4">
        {/* Search Bar */}
        <div className="mb-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-full px-10 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-600 dark:text-blue-300" size={18} />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-600 dark:text-blue-300"
              >
                <X size={18} />
              </button>
            )}
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="mb-4 rounded-xl overflow-hidden shadow-lg">
          <div className="w-full h-[50vh] bg-blue-100 dark:bg-blue-800/30 rounded-xl flex items-center justify-center relative">
            <div className="text-blue-600 dark:text-blue-300 text-center">
              <MapIcon size={48} className="mx-auto mb-2" />
              <p>Interactive Map</p>
              <p className="text-sm opacity-70">Showing {filteredLocations.length} locations</p>
            </div>
            
            {/* Mock location markers */}
            {filteredLocations.slice(0, 4).map((location, index) => (
              <div 
                key={location.id}
                className="absolute cursor-pointer"
                style={{
                  left: `${25 + (index * 15)}%`,
                  top: `${35 + (index * 8)}%`,
                  transform: 'translate(-50%, -50%)'
                }}
                onClick={() => setSelectedLocation(location)}
              >
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md hover:scale-110 transition-transform">
                  {location.icon === 'home' && <Home size={16} />}
                  {location.icon === 'building' && <Building size={16} />}
                  {location.icon === 'coffee' && <Coffee size={16} />}
                  {location.icon === 'shopping' && <ShoppingBag size={16} />}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Location List */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-blue-700 dark:text-blue-200">
            {searchQuery ? 'Search Results' : 'Saved Locations'}
          </h2>
          
          {filteredLocations.length === 0 ? (
            <div className="bg-white dark:bg-blue-800/50 rounded-xl p-4 text-center text-blue-600 dark:text-blue-300">
              No locations found
            </div>
          ) : (
            filteredLocations.map(location => (
              <motion.div
                key={location.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-white dark:bg-blue-800/50 rounded-xl p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow ${
                  selectedLocation?.id === location.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedLocation(location)}
              >
                <div className="flex items-start">
                  <div className="bg-blue-100 dark:bg-blue-700/50 p-2 rounded-full mr-3">
                    {location.icon === 'home' && <Home className="text-blue-600 dark:text-blue-300" size={20} />}
                    {location.icon === 'building' && <Building className="text-blue-600 dark:text-blue-300" size={20} />}
                    {location.icon === 'coffee' && <Coffee className="text-blue-600 dark:text-blue-300" size={20} />}
                    {location.icon === 'shopping' && <ShoppingBag className="text-blue-600 dark:text-blue-300" size={20} />}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold text-blue-700 dark:text-blue-200">{location.name}</h3>
                      {location.delivery && (
                        <span className="bg-green-100 dark:bg-green-800/50 text-green-700 dark:text-green-300 text-xs px-2 py-0.5 rounded-full flex items-center">
                          <Truck size={12} className="mr-1" />
                          Delivery
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-blue-600 dark:text-blue-300 mt-1">{location.description}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{location.address}</p>
                  </div>
                </div>
                
                {selectedLocation?.id === location.id && (
                  <div className="mt-3 pt-3 border-t border-blue-100 dark:border-blue-700/50 flex justify-between">
                    <button className="text-sm text-blue-600 dark:text-blue-300 flex items-center">
                      <Share2 size={16} className="mr-1" />
                      Share
                    </button>
                    <button className="text-sm text-blue-600 dark:text-blue-300 flex items-center">
                      <Navigation size={16} className="mr-1" />
                      Directions
                    </button>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* Add Location Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-blue-900 rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-4 border-b border-blue-100 dark:border-blue-700 flex justify-between items-center">
                <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-200">
                  Add New Location
                </h3>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="text-blue-600 dark:text-blue-300"
                >
                  <X size={20} />
                </button>
              </div>
              
              <form onSubmit={handleAddLocation} className="p-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
                    Location Name
                  </label>
                  <input
                    type="text"
                    value={newLocation.name}
                    onChange={(e) => setNewLocation({...newLocation, name: e.target.value})}
                    placeholder="e.g. My Favorite Café"
                    required
                    className="w-full bg-blue-50 dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    value={newLocation.description}
                    onChange={(e) => setNewLocation({...newLocation, description: e.target.value})}
                    placeholder="Brief description of the location"
                    className="w-full bg-blue-50 dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    value={newLocation.address}
                    onChange={(e) => setNewLocation({...newLocation, address: e.target.value})}
                    placeholder="Full address"
                    required
                    className="w-full bg-blue-50 dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
                      Type
                    </label>
                    <select
                      value={newLocation.type}
                      onChange={(e) => setNewLocation({...newLocation, type: e.target.value})}
                      className="w-full bg-blue-50 dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="personal">Personal</option>
                      <option value="business">Business</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
                      Icon
                    </label>
                    <select
                      value={newLocation.icon}
                      onChange={(e) => setNewLocation({...newLocation, icon: e.target.value})}
                      className="w-full bg-blue-50 dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="home">Home</option>
                      <option value="building">Building</option>
                      <option value="coffee">Coffee</option>
                      <option value="shopping">Shopping</option>
                    </select>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="delivery"
                    checked={newLocation.delivery}
                    onChange={(e) => setNewLocation({...newLocation, delivery: e.target.checked})}
                    className="mr-2"
                  />
                  <label htmlFor="delivery" className="text-sm text-blue-700 dark:text-blue-200">
                    Delivery available
                  </label>
                </div>
                
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg"
                  >
                    Add Location
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}