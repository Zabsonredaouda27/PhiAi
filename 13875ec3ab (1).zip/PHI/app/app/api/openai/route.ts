import { NextResponse } from 'next/server';
import { generateChatCompletion, generateContentSuggestion, isOpenAIConfigured } from '@/lib/openai';

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const { prompt, messages, temperature = 0.7, max_tokens = 500 } = await request.json();

    if (!isOpenAIConfigured()) {
      return NextResponse.json(
        { error: 'OpenAI API key is not configured' },
        { status: 500 }
      );
    }

    let result;

    if (messages) {
      // Chat completion
      result = await generateChatCompletion(messages, { temperature, max_tokens });
      
      return NextResponse.json({
        text: result
      });
    } else if (prompt) {
      // Text completion
      result = await generateContentSuggestion(prompt, { temperature, max_tokens });
      
      return NextResponse.json({
        text: result
      });
    } else {
      return NextResponse.json(
        { error: 'No prompt or messages provided' },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error('OpenAI API error:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred while processing your request' },
      { status: 500 }
    );
  }
}