import { NextResponse } from 'next/server';
import { completions, isOpenAIConfigured } from '@/lib/openai-server';

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    // Check if OpenAI API key is configured
    if (!isOpenAIConfigured()) {
      return NextResponse.json(
        { error: 'OpenAI API key is not configured in server environment' },
        { status: 500 }
      );
    }

    const { prompt, temperature = 0.7, max_tokens = 500 } = await request.json();
    
    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Invalid request format. Prompt is required.' },
        { status: 400 }
      );
    }

    const response = await completions.create({
      model: 'gpt-3.5-turbo-instruct',
      prompt: prompt,
      temperature: temperature,
      max_tokens: max_tokens,
    });

    return NextResponse.json({
      content: response.choices[0].text
    });
  } catch (error: any) {
    console.error('OpenAI API error:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred while processing your request' },
      { status: 500 }
    );
  }
}