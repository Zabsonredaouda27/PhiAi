import { NextResponse } from 'next/server';
import { isOpenAIConfigured } from '@/lib/openai-server';

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const configured = isOpenAIConfigured();
    
    return NextResponse.json({
      configured,
      message: configured 
        ? "OpenAI API key is properly configured" 
        : "OpenAI API key is not configured or invalid"
    });
  } catch (error) {
    console.error('Error checking OpenAI API status:', error);
    return NextResponse.json(
      { 
        configured: false,
        message: "Error checking OpenAI API configuration",
        error: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}