import { NextResponse } from 'next/server';
import { chat, isOpenAIConfigured } from '@/lib/openai-server';

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    // Check if OpenAI API key is configured
    if (!isOpenAIConfigured()) {
      return NextResponse.json(
        { error: 'OpenAI API key is not configured in server environment' },
        { status: 500 }
      );
    }

    const { messages } = await request.json();
    
    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Invalid request format. Messages array is required.' },
        { status: 400 }
      );
    }

    const response = await chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: messages,
      temperature: 0.7,
      max_tokens: 1000,
    });

    return NextResponse.json({
      content: response.choices[0].message.content
    });
  } catch (error: any) {
    console.error('OpenAI API error:', error);
    return NextResponse.json(
      { error: error.message || 'An error occurred while processing your request' },
      { status: 500 }
    );
  }
}