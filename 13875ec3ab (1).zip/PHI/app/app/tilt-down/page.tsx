'use client';

import { useEffect, useState, useRef, useContext } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Briefcase, 
  Search, 
  MapPin, 
  Clock, 
  Filter, 
  Plus, 
  Edit, 
  ChevronRight, 
  Star, 
  StarHalf, 
  Send, 
  X, 
  Check, 
  Upload, 
  Calendar, 
  DollarSign, 
  Users, 
  Bookmark, 
  Share2, 
  Settings
} from 'lucide-react';
import Link from 'next/link';

// Mock data for jobs
const mockJobs = [
  {
    id: 1,
    title: "Quantum Reality Engineer",
    company: "PHI Technologies",
    location: "Paris, France",
    distance: "2.5 km",
    type: "Full-time",
    salary: "€60,000 - €80,000",
    posted: "2 days ago",
    description: "Join our team of reality engineers to develop cutting-edge multiverse navigation technologies.",
    requirements: [
      "3+ years experience in quantum computing",
      "Knowledge of multiverse theory",
      "Experience with reality manipulation algorithms",
      "Strong problem-solving skills"
    ],
    logo: "/ChatPHI.png",
    companyRating: 4.8,
    applications: 12,
    saved: false
  },
  {
    id: 2,
    title: "Multiverse Data Analyst",
    company: "Quantum Insights",
    location: "Remote (Any Reality)",
    distance: "Virtual",
    type: "Contract",
    salary: "€50 - €70 per hour",
    posted: "1 week ago",
    description: "Analyze data patterns across multiple realities to identify trends and opportunities.",
    requirements: [
      "Bachelor's in Data Science or related field",
      "Experience with multidimensional data analysis",
      "Proficiency in Python and R",
      "Strong visualization skills"
    ],
    logo: "/ChatPHI.png",
    companyRating: 4.2,
    applications: 8,
    saved: true
  },
  {
    id: 3,
    title: "Reality Interface Designer",
    company: "Dimension UX",
    location: "Lyon, France",
    distance: "150 km",
    type: "Full-time",
    salary: "€55,000 - €75,000",
    posted: "3 days ago",
    description: "Design intuitive interfaces for users navigating between different realities.",
    requirements: [
      "5+ years of UX/UI design experience",
      "Portfolio showcasing interface designs",
      "Experience with AR/VR technologies",
      "Understanding of human perception across realities"
    ],
    logo: "/ChatPHI.png",
    companyRating: 4.5,
    applications: 15,
    saved: false
  }
];

export default function JobPhiPage() {
  const router = useRouter();
  const [jobs, setJobs] = useState(mockJobs);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filterDistance, setFilterDistance] = useState<number>(50);
  const [filterType, setFilterType] = useState<string>('All');

  // Filter jobs based on search query and filters
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = 
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = filterType === 'All' || job.type === filterType;
    
    const distanceValue = job.distance === "Virtual" ? 0 : parseFloat(job.distance.replace(" km", ""));
    const matchesDistance = distanceValue <= filterDistance;
    
    return matchesSearch && matchesType && matchesDistance;
  });

  // Handle saving/unsaving a job
  const handleSaveJob = (jobId: number) => {
    setJobs(jobs.map(job => 
      job.id === jobId ? { ...job, saved: !job.saved } : job
    ));
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-blue-950 dark:to-blue-900">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 dark:bg-blue-900/80 backdrop-blur-md shadow-sm p-4">
        <div className="max-w-1200 mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center justify-center p-2 rounded-full bg-blue-100 dark:bg-blue-800 hover:bg-blue-200 dark:hover:bg-blue-700 transition-colors">
              <Briefcase className="text-blue-600 dark:text-blue-300" size={20} />
            </Link>
            <h1 className="ml-3 text-xl font-bold text-blue-700 dark:text-blue-200">Job φ</h1>
          </div>
        </div>
      </header>

      <div className="max-w-1200 mx-auto p-4">
        {/* Search Bar */}
        <div className="mb-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search jobs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-blue-800/50 text-blue-700 dark:text-blue-200 rounded-full px-10 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-600 dark:text-blue-300" size={18} />
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-600 dark:text-blue-300"
            >
              <Filter size={18} />
            </button>
          </div>
        </div>

        {/* Filters */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white dark:bg-blue-800/50 rounded-xl p-4 mb-4 shadow-sm overflow-hidden"
            >
              <h3 className="text-blue-700 dark:text-blue-200 font-medium mb-3">Filters</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-blue-600 dark:text-blue-300 mb-1">
                    Maximum Distance: {filterDistance} km
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    step="10"
                    value={filterDistance}
                    onChange={(e) => setFilterDistance(parseInt(e.target.value))}
                    className="w-full h-2 bg-blue-200 dark:bg-blue-700 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-blue-600 dark:text-blue-300 mb-1">
                    Job Type
                  </label>
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="w-full bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="All">All Types</option>
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                  </select>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Job List */}
        <AnimatePresence mode="wait">
          {selectedJob ? (
            <motion.div
              key="job-detail"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white dark:bg-blue-800/50 rounded-xl shadow-lg overflow-hidden"
            >
              <div className="p-4 border-b border-blue-100 dark:border-blue-700/50 flex items-center justify-between">
                <button 
                  onClick={() => setSelectedJob(null)}
                  className="flex items-center text-blue-600 dark:text-blue-300"
                >
                  <ChevronRight size={18} className="mr-1 rotate-180" />
                  <span>Back to jobs</span>
                </button>
                
                <button 
                  onClick={() => handleSaveJob(selectedJob.id)}
                  className={`p-2 rounded-full ${
                    selectedJob.saved 
                      ? 'bg-blue-100 dark:bg-blue-700 text-blue-600 dark:text-blue-300' 
                      : 'bg-gray-100 dark:bg-blue-900/30 text-gray-500 dark:text-gray-400'
                  }`}
                >
                  <Bookmark size={18} fill={selectedJob.saved ? 'currentColor' : 'none'} />
                </button>
              </div>
              
              <div className="p-4">
                <div className="flex items-start mb-4">
                  <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-white mr-3 flex-shrink-0">
                    <Image
                      src={selectedJob.logo}
                      alt={selectedJob.company}
                      fill
                      className="object-contain p-2"
                    />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-blue-700 dark:text-blue-200">
                      {selectedJob.title}
                    </h2>
                    <div className="flex items-center text-blue-600 dark:text-blue-300 text-sm">
                      <span>{selectedJob.company}</span>
                      <span className="mx-1">•</span>
                      <div className="flex items-center">
                        {Array.from({ length: Math.floor(selectedJob.companyRating) }).map((_, i) => (
                          <Star key={i} size={14} fill="currentColor" />
                        ))}
                        {selectedJob.companyRating % 1 !== 0 && (
                          <StarHalf size={14} fill="currentColor" />
                        )}
                        <span className="ml-1">{selectedJob.companyRating}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg">
                    <div className="flex items-center text-blue-600 dark:text-blue-300 text-sm mb-1">
                      <MapPin size={14} className="mr-1" />
                      <span>Location</span>
                    </div>
                    <p className="text-blue-700 dark:text-blue-200 font-medium">
                      {selectedJob.location}
                    </p>
                    <p className="text-xs text-blue-500 dark:text-blue-400">
                      {selectedJob.distance}
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg">
                    <div className="flex items-center text-blue-600 dark:text-blue-300 text-sm mb-1">
                      <Briefcase size={14} className="mr-1" />
                      <span>Job Type</span>
                    </div>
                    <p className="text-blue-700 dark:text-blue-200 font-medium">
                      {selectedJob.type}
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg">
                    <div className="flex items-center text-blue-600 dark:text-blue-300 text-sm mb-1">
                      <DollarSign size={14} className="mr-1" />
                      <span>Salary</span>
                    </div>
                    <p className="text-blue-700 dark:text-blue-200 font-medium">
                      {selectedJob.salary}
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-lg">
                    <div className="flex items-center text-blue-600 dark:text-blue-300 text-sm mb-1">
                      <Clock size={14} className="mr-1" />
                      <span>Posted</span>
                    </div>
                    <p className="text-blue-700 dark:text-blue-200 font-medium">
                      {selectedJob.posted}
                    </p>
                    <p className="text-xs text-blue-500 dark:text-blue-400">
                      {selectedJob.applications} applications
                    </p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-200 mb-2">
                    Job Description
                  </h3>
                  <p className="text-blue-600 dark:text-blue-300">
                    {selectedJob.description}
                  </p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-200 mb-2">
                    Requirements
                  </h3>
                  <ul className="space-y-2">
                    {selectedJob.requirements.map((req: string, index: number) => (
                      <li key={index} className="flex items-start">
                        <span className="text-blue-500 dark:text-blue-400 mr-2">•</span>
                        <span className="text-blue-600 dark:text-blue-300">{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={() => handleSaveJob(selectedJob.id)}
                    className={`flex-1 py-3 rounded-xl flex items-center justify-center ${
                      selectedJob.saved 
                        ? 'bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-300' 
                        : 'bg-gray-100 dark:bg-blue-900/30 text-gray-600 dark:text-gray-300'
                    }`}
                  >
                    <Bookmark size={18} className="mr-2" fill={selectedJob.saved ? 'currentColor' : 'none'} />
                    {selectedJob.saved ? 'Saved' : 'Save'}
                  </button>
                  
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl flex items-center justify-center">
                    <Send size={18} className="mr-2" />
                    Apply Now
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="job-list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {filteredJobs.length === 0 ? (
                <div className="bg-white dark:bg-blue-800/50 rounded-xl p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <Search size={40} className="text-blue-400 dark:text-blue-500" />
                  </div>
                  <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-200 mb-2">
                    No jobs found
                  </h3>
                  <p className="text-blue-600 dark:text-blue-300">
                    Try adjusting your search or filters to find more opportunities.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredJobs.map(job => (
                    <motion.div
                      key={job.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-white dark:bg-blue-800/50 rounded-xl p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedJob(job)}
                    >
                      <div className="flex items-start">
                        <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-white mr-3 flex-shrink-0">
                          <Image
                            src={job.logo}
                            alt={job.company}
                            fill
                            className="object-contain p-2"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h3 className="font-semibold text-blue-700 dark:text-blue-200">{job.title}</h3>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSaveJob(job.id);
                              }}
                              className="text-blue-600 dark:text-blue-300"
                            >
                              <Bookmark size={18} fill={job.saved ? 'currentColor' : 'none'} />
                            </button>
                          </div>
                          <p className="text-sm text-blue-600 dark:text-blue-300">{job.company}</p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <span className="bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-300 text-xs px-2 py-1 rounded-full flex items-center">
                              <MapPin size={12} className="mr-1" />
                              {job.distance}
                            </span>
                            <span className="bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-300 text-xs px-2 py-1 rounded-full">
                              {job.type}
                            </span>
                            <span className="bg-blue-100 dark:bg-blue-800 text-blue-600 dark:text-blue-300 text-xs px-2 py-1 rounded-full flex items-center">
                              <Clock size={12} className="mr-1" />
                              {job.posted}
                            </span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </main>
  );
}