'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Key, Check, AlertCircle, X } from 'lucide-react';
import { isOpenAIConfigured } from '@/lib/openai';

interface ApiKeySetupProps {
  onClose?: () => void;
  showCloseButton?: boolean;
}

export default function ApiKeySetup({ onClose, showCloseButton = true }: ApiKeySetupProps) {
  const [apiKey, setApiKey] = useState('');
  const [isConfigured, setIsConfigured] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    // Check if API key is already configured
    setIsConfigured(isOpenAIConfigured());
  }, []);

  const handleSaveApiKey = () => {
    if (!apiKey.trim()) {
      setError('Please enter a valid API key');
      return;
    }

    setIsSaving(true);
    setError('');

    try {
      // In a real app, we would securely store this
      // For demo purposes, we're using localStorage
      localStorage.setItem('openai_api_key', apiKey);
      
      // Set the API key in the environment variable (this is just for demo)
      // In a real app, this would be handled server-side
      if (typeof window !== 'undefined') {
        // @ts-ignore - This is just for demo purposes
        window.process = window.process || {};
        // @ts-ignore - This is just for demo purposes
        window.process.env = window.process.env || {};
        // @ts-ignore - This is just for demo purposes
        window.process.env.NEXT_PUBLIC_OPENAI_API_KEY = apiKey;
      }
      
      setSuccess(true);
      setIsConfigured(true);
      
      // Reset success message after 3 seconds
      setTimeout(() => {
        setSuccess(false);
        if (onClose) onClose();
      }, 3000);
    } catch (err) {
      setError('Failed to save API key. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white dark:bg-blue-800/50 rounded-xl shadow-lg p-6"
    >
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-blue-700 dark:text-blue-200 flex items-center">
          <Key className="mr-2" size={20} />
          OpenAI API Setup
        </h2>
        {showCloseButton && onClose && (
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-blue-100 dark:hover:bg-blue-700 text-blue-600 dark:text-blue-300"
          >
            <X size={20} />
          </button>
        )}
      </div>
      
      {isConfigured ? (
        <div className="flex items-center text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 p-3 rounded-lg mb-4">
          <Check className="mr-2" size={20} />
          <p>OpenAI API is configured and ready to use!</p>
        </div>
      ) : (
        <>
          <p className="text-blue-600 dark:text-blue-300 mb-4">
            To use AI features in PHI, please enter your OpenAI API key below. You can get an API key from the <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-blue-500 underline">OpenAI dashboard</a>.
          </p>
          
          <div className="mb-4">
            <label htmlFor="api-key" className="block text-sm font-medium text-blue-700 dark:text-blue-200 mb-1">
              OpenAI API Key
            </label>
            <input
              id="api-key"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="sk-..."
              className="w-full bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          {error && (
            <div className="flex items-center text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-3 rounded-lg mb-4">
              <AlertCircle className="mr-2" size={20} />
              <p>{error}</p>
            </div>
          )}
          
          {success && (
            <div className="flex items-center text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 p-3 rounded-lg mb-4">
              <Check className="mr-2" size={20} />
              <p>API key saved successfully!</p>
            </div>
          )}
          
          <button
            onClick={handleSaveApiKey}
            disabled={isSaving}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg flex items-center justify-center"
          >
            {isSaving ? 'Saving...' : 'Save API Key'}
          </button>
          
          <p className="text-xs text-blue-500 dark:text-blue-400 mt-3">
            Your API key is stored locally on your device and is never sent to our servers. It is used only to make requests to the OpenAI API.
          </p>
        </>
      )}
    </motion.div>
  );
}