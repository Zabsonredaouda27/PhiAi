'use client';

import { useState, useRef, useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useSwipe } from '@/hooks/use-swipe';
import SidebarMenu from '@/components/sidebar-menu';
import { useContext } from 'react';
import { ScrollSettingsContext } from '@/contexts/scroll-settings-context';

interface PageLayoutProps {
  children: React.ReactNode;
}

export default function PageLayout({ children }: PageLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const pageRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();
  const router = useRouter();
  const { resetInitialTilt } = useContext(ScrollSettingsContext);

  // Reset initial tilt when navigating between pages
  useEffect(() => {
    resetInitialTilt();
  }, [pathname, resetInitialTilt]);

  // Handle navigation completion
  useEffect(() => {
    const handleRouteChangeComplete = () => {
      // Reset any loading states or perform cleanup
      console.log('Route change completed to:', pathname);
    };

    handleRouteChangeComplete();
  }, [pathname]);

  const openSidebar = () => {
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  // Setup swipe detection
  useSwipe(pageRef, {
    onSwipeRight: openSidebar,
    onSwipeLeft: closeSidebar,
  });

  return (
    <div ref={pageRef} className="min-h-screen">
      <SidebarMenu isOpen={isSidebarOpen} onClose={closeSidebar} />
      {children}
    </div>
  );
}