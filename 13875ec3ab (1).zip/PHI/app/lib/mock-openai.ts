// Mock OpenAI service for when the API is unavailable

export interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// Mock responses for different types of requests
const mockChatResponses = [
  "I'm a mock AI assistant. The OpenAI API is currently unavailable, but I can still help you explore the PHI application!",
  "This is a simulated response. In a real scenario, I would be powered by OpenAI's advanced language models.",
  "Welcome to PHI! Even without the full AI capabilities, you can still navigate through all sections of the application.",
  "I'm here to demonstrate the chat functionality. The real AI would provide more sophisticated responses.",
  "Thank you for trying out PHI! This mock response shows how the interface works when the API is offline.",
  "The PHI application is designed to work seamlessly even when AI features are limited. Explore all the sections!",
  "This is a demonstration of the chat interface. The actual AI would understand context and provide personalized responses.",
  "PHI offers multiple sections including Chat, Multi φ, Job φ, Map φ, and Game φ. Feel free to explore them all!"
];

const mockContentSuggestions = {
  social: [
    "Just discovered an amazing new reality through PHI! The possibilities are endless when you can navigate between dimensions. #PHIexplorer #multiverse",
    "Working on some exciting quantum projects today. PHI makes interdimensional collaboration so much easier! #quantumtech #innovation",
    "The multiverse is vast and full of wonders. Every reality has its own unique beauty and challenges. #philosophy #exploration",
    "PHI has revolutionized how we think about reality and existence. What started as science fiction is now our daily reality! #technology #future"
  ],
  job: [
    "Based on your experience in quantum computing and multiverse theory, you would be an excellent fit for this position. Your background in reality manipulation algorithms demonstrates the technical skills required.",
    "Your resume shows strong qualifications for this role. Consider highlighting your experience with interdimensional communication systems and quantum interface design.",
    "This position requires expertise in multiverse navigation technologies, which aligns well with your background. Your skills in reality-shifting protocols would be particularly valuable.",
    "Your educational background in Quantum Physics and practical experience with PHI technologies make you a strong candidate for this quantum engineering role."
  ],
  travel: [
    "Day 1: Start your journey in the historic center, visiting the main quantum portal and the Museum of Interdimensional Art. Lunch at the Parallel Café for cuisine from multiple realities.\n\nDay 2: Explore the Quantum Gardens and take a guided tour through the Reality Observatory. Evening at the Multiverse Theater for performances from different dimensions.\n\nDay 3: Adventure day with reality-hopping excursions and visits to the local markets selling goods from various universes.",
    "For a perfect weekend getaway, I recommend visiting the Quantum Springs resort. Day 1: Relax at the interdimensional spa and enjoy reality-shifting meditation sessions. Day 2: Take the scenic route through the Probability Fields and visit the famous Schrödinger's Café.",
    "This destination offers unique experiences across multiple realities. Must-visit locations include the Temporal Gardens, the Museum of Parallel Histories, and the Quantum Marketplace. Don't miss the sunset viewing from the Reality Bridge!"
  ],
  game: [
    "I'll make a strategic move to block your winning opportunity while setting up my own. Let me place my piece in the center position to control the board.",
    "Analyzing the current game state... I'll take the corner position to maximize my chances of winning. This move also prevents you from creating a winning line.",
    "Good move! I'll counter by taking the opposite corner. This creates multiple potential winning paths for my next turn.",
    "I'll play defensively here and block your potential winning move. The game is getting interesting!"
  ]
};

// Mock chat completion function
export async function mockChatCompletion(messages: OpenAIMessage[]): Promise<string> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
  
  // Get the last user message to provide context-aware responses
  const lastUserMessage = messages.filter(m => m.role === 'user').pop();
  const userContent = lastUserMessage?.content.toLowerCase() || '';
  
  // Provide contextual responses based on user input
  if (userContent.includes('hello') || userContent.includes('hi')) {
    return "Hello! I'm a mock AI assistant. While the OpenAI API is unavailable, I can still demonstrate the chat functionality of PHI. How can I help you explore the application?";
  }
  
  if (userContent.includes('phi') || userContent.includes('app')) {
    return "PHI is an amazing application with multiple sections! You can explore ChatPHI (where we are now), Multi φ for social features, Job φ for career opportunities, Map φ for location services, and Game φ for entertainment. All sections are fully accessible even without the full AI features.";
  }
  
  if (userContent.includes('multiverse') || userContent.includes('reality')) {
    return "The multiverse is a fascinating concept! PHI allows you to explore different realities and dimensions. While this is a mock response, the real application would provide deep insights into quantum mechanics and parallel universes.";
  }
  
  if (userContent.includes('help') || userContent.includes('how')) {
    return "I'm here to help! Even though this is a mock AI service, you can still navigate through all sections of PHI. Try visiting the other sections using the navigation buttons or the sidebar menu. Each section has its own unique features and mock AI capabilities.";
  }
  
  // Return a random response for other inputs
  const randomIndex = Math.floor(Math.random() * mockChatResponses.length);
  return mockChatResponses[randomIndex];
}

// Mock content suggestion function
export async function mockContentSuggestion(prompt: string): Promise<string> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1500));
  
  const promptLower = prompt.toLowerCase();
  
  // Determine the type of content based on the prompt
  if (promptLower.includes('social') || promptLower.includes('post') || promptLower.includes('multiverse')) {
    const suggestions = mockContentSuggestions.social;
    return suggestions[Math.floor(Math.random() * suggestions.length)];
  }
  
  if (promptLower.includes('job') || promptLower.includes('resume') || promptLower.includes('career')) {
    const suggestions = mockContentSuggestions.job;
    return suggestions[Math.floor(Math.random() * suggestions.length)];
  }
  
  if (promptLower.includes('travel') || promptLower.includes('trip') || promptLower.includes('itinerary')) {
    const suggestions = mockContentSuggestions.travel;
    return suggestions[Math.floor(Math.random() * suggestions.length)];
  }
  
  if (promptLower.includes('game') || promptLower.includes('move') || promptLower.includes('strategy')) {
    const suggestions = mockContentSuggestions.game;
    return suggestions[Math.floor(Math.random() * suggestions.length)];
  }
  
  // Default response for unrecognized prompts
  return "This is a mock AI response. The OpenAI API is currently unavailable, but this demonstrates how the application would work with AI features enabled. The actual AI would provide more sophisticated and contextual responses based on your specific request.";
}

// Mock API status check
export async function mockApiStatus(): Promise<boolean> {
  // Always return false to simulate API unavailability
  return false;
}

// Check if we should use mock responses
export function shouldUseMockAPI(): boolean {
  // Check if running in development mode or if API key is not configured
  if (typeof window !== 'undefined') {
    // Client-side check
    return true; // Always use mock on client side for this implementation
  }
  
  // Server-side check
  const apiKey = process.env.OPENAI_API_KEY;
  return !apiKey || !apiKey.startsWith('sk-');
}