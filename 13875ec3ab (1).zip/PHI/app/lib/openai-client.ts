// Client-side OpenAI utilities - simplified without mock interference

export interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// Helper function to generate chat completions
export async function generateChatCompletion(messages: OpenAIMessage[], options = {}) {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ messages, ...options }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate chat completion');
    }

    const data = await response.json();
    return data.content;
  } catch (error) {
    console.error('Error generating chat completion:', error);
    throw error;
  }
}

// Helper function to generate content suggestions
export async function generateContentSuggestion(prompt: string, options = {}) {
  try {
    const response = await fetch('/api/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt, ...options }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate content suggestion');
    }

    const data = await response.json();
    return data.content;
  } catch (error) {
    console.error('Error generating content suggestion:', error);
    throw error;
  }
}

// Helper function to check OpenAI API status
export async function checkOpenAIStatus() {
  try {
    const response = await fetch('/api/status', {
      method: 'GET',
    });
    
    if (!response.ok) {
      return false;
    }
    
    const data = await response.json();
    return data.configured;
  } catch (error) {
    console.error('Error checking API status:', error);
    return false;
  }
}

// Check if OpenAI is configured (simplified)
export function isOpenAIConfigured(): boolean {
  // This will be determined by the server-side API
  return true; // Default to true, let server handle the actual check
}

// Remove mock API check - always use real API
export function isUsingMockAPI(): boolean {
  return false;
}