// Server-side OpenAI utilities without external dependency

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface ChatCompletionRequest {
  model: string;
  messages: OpenAIMessage[];
  temperature?: number;
  max_tokens?: number;
}

interface CompletionRequest {
  model: string;
  prompt: string;
  temperature?: number;
  max_tokens?: number;
}

interface ChatCompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: {
    message: {
      role: string;
      content: string;
    };
    index: number;
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

interface CompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: {
    text: string;
    index: number;
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

// Custom OpenAI client implementation
class CustomOpenAIClient {
  private apiKey: string;
  
  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }
  
  async createChatCompletion(options: ChatCompletionRequest): Promise<ChatCompletionResponse> {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(options)
      });
      
      if (!response.ok) {
        const error = await response.json();
        console.error('OpenAI API error:', error);
        throw new Error(error.error?.message || 'Failed to generate chat completion');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error in createChatCompletion:', error);
      throw error;
    }
  }
  
  async createCompletion(options: CompletionRequest): Promise<CompletionResponse> {
    try {
      const response = await fetch('https://api.openai.com/v1/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(options)
      });
      
      if (!response.ok) {
        const error = await response.json();
        console.error('OpenAI API error:', error);
        throw new Error(error.error?.message || 'Failed to generate completion');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error in createCompletion:', error);
      throw error;
    }
  }
}

// Initialize OpenAI client with API key from environment variables
let openaiInstance: CustomOpenAIClient | null = null;

export function getOpenAIClient(): CustomOpenAIClient {
  if (!openaiInstance) {
    // Use server-side environment variable for API key
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey) {
      console.error('OpenAI API key is not set in environment variables. Please check your .env.local file.');
      throw new Error('OpenAI API key is not set in environment variables');
    }
    
    openaiInstance = new CustomOpenAIClient(apiKey);
  }
  
  return openaiInstance;
}

// Helper function to check if OpenAI API key is configured
export function isOpenAIConfigured(): boolean {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    // Check if API key exists and has the correct format (starts with 'sk-')
    if (!apiKey || !apiKey.startsWith('sk-')) {
      console.warn('OpenAI API key is missing or has an invalid format. Please check your .env.local file.');
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error checking OpenAI configuration:', error);
    return false;
  }
}

// Namespace to match the structure of the OpenAI SDK
export const chat = {
  completions: {
    create: async (options: ChatCompletionRequest) => {
      try {
        const client = getOpenAIClient();
        return await client.createChatCompletion(options);
      } catch (error) {
        console.error('Error in chat.completions.create:', error);
        throw error;
      }
    }
  }
};

export const completions = {
  create: async (options: CompletionRequest) => {
    try {
      const client = getOpenAIClient();
      return await client.createCompletion(options);
    } catch (error) {
      console.error('Error in completions.create:', error);
      throw error;
    }
  }
};