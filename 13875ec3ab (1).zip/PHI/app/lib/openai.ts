// Custom OpenAI client implementation without external dependency

export interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface ChatCompletionOptions {
  model?: string;
  temperature?: number;
  max_tokens?: number;
}

interface CompletionOptions {
  model?: string;
  temperature?: number;
  max_tokens?: number;
}

class CustomOpenAI {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async createChatCompletion(messages: OpenAIMessage[], options: ChatCompletionOptions = {}) {
    const { model = 'gpt-3.5-turbo', temperature = 0.7, max_tokens = 1000 } = options;

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model,
          messages,
          temperature,
          max_tokens
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate chat completion');
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Error generating chat completion:', error);
      throw error;
    }
  }

  async createCompletion(prompt: string, options: CompletionOptions = {}) {
    const { model = 'gpt-3.5-turbo-instruct', temperature = 0.7, max_tokens = 500 } = options;

    try {
      const response = await fetch('https://api.openai.com/v1/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model,
          prompt,
          temperature,
          max_tokens
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate completion');
      }

      const data = await response.json();
      return data.choices[0].text;
    } catch (error) {
      console.error('Error generating completion:', error);
      throw error;
    }
  }
}

// Initialize OpenAI client with API key from environment variables
const getOpenAIClient = () => {
  const apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
  
  if (!apiKey) {
    console.warn('OpenAI API key is not set. Please add your API key to the environment variables.');
    return null;
  }
  
  return new CustomOpenAI(apiKey);
};

// Check if OpenAI API key is set
export const isOpenAIConfigured = () => {
  if (typeof window !== 'undefined') {
    return !!localStorage.getItem('openai_api_key');
  }
  return !!process.env.NEXT_PUBLIC_OPENAI_API_KEY;
};

// Helper function to generate chat completions
export async function generateChatCompletion(messages: OpenAIMessage[], options = {}) {
  let apiKey = '';
  
  if (typeof window !== 'undefined') {
    apiKey = localStorage.getItem('openai_api_key') || '';
  } else {
    apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
  }
  
  if (!apiKey) {
    throw new Error('OpenAI API key is not configured. Please add your API key.');
  }
  
  const client = new CustomOpenAI(apiKey);
  
  try {
    return await client.createChatCompletion(messages, options);
  } catch (error) {
    console.error('Error generating chat completion:', error);
    throw error;
  }
}

// Helper function to generate content suggestions
export async function generateContentSuggestion(prompt: string, options = {}) {
  let apiKey = '';
  
  if (typeof window !== 'undefined') {
    apiKey = localStorage.getItem('openai_api_key') || '';
  } else {
    apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
  }
  
  if (!apiKey) {
    throw new Error('OpenAI API key is not configured. Please add your API key.');
  }
  
  const client = new CustomOpenAI(apiKey);
  
  try {
    return await client.createCompletion(prompt, options);
  } catch (error) {
    console.error('Error generating content suggestion:', error);
    throw error;
  }
}