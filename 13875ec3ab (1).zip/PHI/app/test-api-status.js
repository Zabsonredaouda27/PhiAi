// Test script to check the API status endpoint
require('dotenv').config({ path: '.env.local' });

async function testApiStatus() {
  try {
    console.log('Testing API status endpoint...');
    
    // Create a simple HTTP server to handle the response
    const http = require('http');
    const server = http.createServer(async (req, res) => {
      if (req.url === '/api/status') {
        // Simulate the status endpoint
        const apiKey = process.env.OPENAI_API_KEY;
        const isConfigured = !!apiKey && apiKey.startsWith('sk-');
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          configured: isConfigured,
          message: isConfigured 
            ? "OpenAI API key is properly configured" 
            : "OpenAI API key is not configured or invalid"
        }));
      } else {
        res.writeHead(404);
        res.end();
      }
    });
    
    // Start the server on a random port
    server.listen(0, async () => {
      const port = server.address().port;
      console.log(`Test server running on port ${port}`);
      
      try {
        // Make a request to the status endpoint
        const response = await fetch(`http://localhost:${port}/api/status`);
        const data = await response.json();
        
        console.log('API Status Response:', data);
        console.log('API Key Configured:', data.configured);
        console.log('Message:', data.message);
        
        // Check if the API key is valid by making a test request to OpenAI
        if (data.configured) {
          console.log('\nTesting OpenAI API key with a direct request...');
          const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
            },
            body: JSON.stringify({
              model: 'gpt-3.5-turbo',
              messages: [{ role: 'user', content: 'Hello, are you working?' }],
              max_tokens: 50
            })
          });
          
          if (openaiResponse.ok) {
            const openaiData = await openaiResponse.json();
            console.log('OpenAI API Response:', openaiData.choices[0].message.content);
            console.log('OpenAI API Key is working correctly!');
          } else {
            const errorData = await openaiResponse.json();
            console.error('OpenAI API Error:', errorData);
            console.error('OpenAI API Key is not working correctly.');
          }
        }
      } catch (error) {
        console.error('Error testing API status:', error);
      } finally {
        // Close the server
        server.close();
      }
    });
  } catch (error) {
    console.error('Error testing API status:', error);
  }
}

testApiStatus();
